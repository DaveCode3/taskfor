@extends('layouts.app')

@section('content')
    <div class="container">
    <form method="POST"  action="/addstore">
   
    @csrf
    <div class="form-group">
            <label for="" >Schoolname</label>
            <input class="form-control" type="text" name="schoolname" id="schoolname">
            @error('schoolname')
            <span class="invalid-feedback" role="alert">
                   <h1>< <strong>{{ $message }}</strong></h1>
            </span>
            @enderror
        </div>
        <div class="form-group">
            <label for="">Address</label>
            <input  class="form-control" type="text" name="address" id="address"> 
            @error('address')
            <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
            </span>
            @enderror
        </div>
        <div class="form-group">
            <label for="">City</label>
            <input  class="form-control" type="text" name="city" id="city">
            @error('city')
            <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
            </span>
            @enderror
        </div>
        <div class="form-group">
            <label for="">County</label>
            <input  class="form-control" type="text" name="country" id="country">
            @error('country')
            <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
            </span>
            @enderror
        </div>
        <div class="form-group">
            <label for="">Postcode</label>
            <input  class="form-control" type="text" name="postcode" id="postcode">
            @error('postcode')
            <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
            </span>
            @enderror
            
        </div>
    
        <input class="btn btn-primary" type="submit" value="submit">
        </div>
    </form>


    </div>
    @endsection
