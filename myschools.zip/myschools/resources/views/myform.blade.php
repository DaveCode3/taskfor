<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/css/bootstrap.css">
    <link rel="stylesheet" href="/formstyle.css">
</head>
<body>
<nav class="navbar navbar-dark bg-dark">
    <div class="navbar-brand">NAVBAR</div>
    </nav>
  <div class="fstyle">
<h1 id="hellos">Pick</h1> 
<div class="form-check">

<form method="POST" action="/storelist">
       @csrf
       @foreach($datasch as $datas)
       <div class="classdiv">
        <input  type="checkbox" name="myschool[]" value="{{$datas->schoolname}}"  onclick="return myfun()"> {{$datas->schoolname}}
        </div>
        @endforeach
   <input type="submit" value="submit"> 
   </form>
       
</div>
   </div>  

   <div>
       <span id="notvalid">  </span>
   </div>

   <div class="myvalues">
        @foreach($datasch as $datas)
        <div class="pdatas">
            {{$datas->schoolname}}
        </div>

        @endforeach
   </div>


   <script src="./formscript.js"></script>  
</body>
</html>