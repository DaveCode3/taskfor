@extends('layouts.app')

@section('content')
    <h1>Hello</h1>
@foreach($mydisp as $disp)
   
@php
$mydispdat =json_decode($disp->schoollist)
@endphp

@foreach($mydispdat as $displayli)

<li> {{$displayli}}</li>
   
@endforeach
    @endforeach

    @endsection