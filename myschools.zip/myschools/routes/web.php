<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ListController;
use App\Http\Controllers\AddController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/myform',[ListController::class,'listschool']); 
Route::post('/storelist',[ListController::class,'storelist'] );

Route::get('/addschool',[AddController::class,'regschool']);
Route::post('/addstore',[AddController::class,'addstore'] ); 
Route::get('/display',[ListController::class,'listdisplay']);




Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
