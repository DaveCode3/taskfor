console.log("rockyyy");


var arty = document.getElementById("hellos");
console.log(arty);

function myfun(){
    var a =document.getElementsByName('myschool[]')
    var newvar =0;
    var count;
    for(count=0;count<a.length;count++){
        if(a[count].checked==true){
            newvar =newvar+1;

        }
    }
    if(newvar>=4){
        document.getElementById("notvalid").innerHTML ="** pleasw select only 4";
        return false;
    }
}