<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Models\Addlist;
use Illuminate\Validation\Validator;

class AddController extends Controller
{
    public function regschool(){ 
        return view('addschool' );
    }
    
    public function addstore(Request $request){
        $validateData =$request->validate([
            'schoolname'=>'required|unique:addlists',
            'address'=>'required',
            'city'=>'required',
            'country'=>'required',
            'postcode'=>'required|integer',
        ]);
 
        $schoo = new Addlist();
        $schoo ->schoolname =$request->post('schoolname');
        $schoo ->address =$request->post('address');
        $schoo ->city =$request->post('city');
        $schoo ->country =$request->post('country');
        $schoo ->postcode =$request->post('postcode');
        $schoo->save();
            return back();
        }

       
}
