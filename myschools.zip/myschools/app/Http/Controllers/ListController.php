<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Mylist;
use App\Models\Addlist;


class ListController extends Controller
{
    public function listschool(){ 
       
        $datasch =  Addlist::all();
        return view('myform',['datasch' =>$datasch]);
    }

    public function deleteList(Request $request){
        $ids = $request->myschool;
        Addlist::whereIn('schoolname',$ids)->delete();
        return redirect()->back();
    }

    
    public function storelist(Request $request){
        
                $datasch = new Mylist();
                $datasch->schoollist = json_encode($request->myschool );
                

                $datasch->save();
                $this->deleteList($request);
                return redirect()->back();        
         }

         public function listdisplay(){ 
            $mydisp =  Mylist::all();
            return view('displaylist',['mydisp' =>$mydisp] );
        }

}


